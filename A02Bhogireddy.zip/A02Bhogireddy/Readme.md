 44-563-04 A02Bhogireddy Assignment using BootStrap

Learning JavaScript and jQuery by interacting with a user. 

# Uses

- jQuery, a JavaScript library that simplifies client-side scripting
- BootStrap, a framework for responsive web design 
- JavaScript, a scripting language for the web
- HTML, a markup language for web apps
- CSS, a style sheet language for styling markup languages such as html

# Getting Started

Visual Studio Code is used for coding. 

# Frameworks and Libraries

- JQuery: https://jquery.com/
- BootStrap: http://getbootstrap.com/
- QUnit: https://qunitjs.com/


# Description about page"
Hello!!

Thanks for visiting my store.

Let me give you a brief idea about the site.

This site provides you a wide variety of Musical instruments, even the legacy instruments, where you can select your taste at low price.

Suggestions:

Compare the product at any store and you will come back to us.

Directions:

1)After reading our About page, please click on "Pick it".
2) Click on the check box below the product u selected.
3) Click on order, that's it you are done with the payment method as next step.
4) For any queries, please submit your details or call us at the number mentioned anytime.